import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class DeviceControlPage extends JPanel {

    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public DeviceControlPage() {
        setLayout(new BorderLayout());
        setBackground(new Color(134, 133, 239));
        add(createDevicePanel(), BorderLayout.CENTER);
    }

    private JPanel createDevicePanel() {
        JPanel devicePanel = new JPanel();
        devicePanel.setLayout(new BoxLayout(devicePanel, BoxLayout.Y_AXIS));
        devicePanel.setBackground(new Color(134, 133, 239));
        devicePanel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JLabel titleLabel = new JLabel("Device Control");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 22));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        devicePanel.add(titleLabel);
        devicePanel.add(Box.createRigidArea(new Dimension(0, 20)));

        try (Connection connection = DatabaseConfig.getConnection();
             PreparedStatement stmt = connection.prepareStatement("SELECT * FROM device");
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                String deviceName = rs.getString("devicename");
                int pin = rs.getInt("pin");
                double standardEnergy = rs.getDouble("standard_energy");
                String status = rs.getString("status");

                JPanel rowPanel = new JPanel(new BorderLayout());
                rowPanel.setBackground(new Color(60, 60, 60));
                rowPanel.setBorder(new EmptyBorder(5, 10, 5, 10));
                rowPanel.setPreferredSize(new Dimension(300, 25)); // Fixed height

                JLabel deviceLabel = new JLabel(deviceName);
                deviceLabel.setFont(new Font("Arial", Font.PLAIN, 16));
                deviceLabel.setForeground(Color.WHITE);

                JToggleButton toggleButton = new JToggleButton(status);
                toggleButton.setFont(new Font("Arial", Font.BOLD, 14));
                toggleButton.setForeground(Color.WHITE);
                toggleButton.setBackground(status.equals("ON") ? Color.GREEN : Color.RED);
                toggleButton.setFocusPainted(false);

                toggleButton.addActionListener((ActionEvent e) -> handleToggleButton(toggleButton, pin, standardEnergy));

                rowPanel.add(deviceLabel, BorderLayout.WEST);
                rowPanel.add(toggleButton, BorderLayout.EAST);

                // Wrap rowPanel inside another panel with a fixed size to maintain height
                JPanel wrapperPanel = new JPanel(new BorderLayout());
                wrapperPanel.setPreferredSize(new Dimension(300, 25)); // Fixed height
                wrapperPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 25)); // Prevent stretching
                wrapperPanel.add(rowPanel, BorderLayout.CENTER);

                devicePanel.add(wrapperPanel);
                devicePanel.add(Box.createRigidArea(new Dimension(0, 5))); // Space between rows
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error fetching devices from database.");
            e.printStackTrace();
        }

        return devicePanel;
    }
    private void handleToggleButton(JToggleButton toggleButton, int pin, double standardEnergy) {
        try (Connection connection = DatabaseConfig.getConnection()) {
            String newStatus = toggleButton.isSelected() ? "ON" : "OFF";
            toggleButton.setText(newStatus);
            toggleButton.setBackground(newStatus.equals("ON") ? Color.GREEN : Color.RED);

            // Send command to Arduino
            if (DashboardPage.serialPort != null && DashboardPage.serialPort.isOpen()) {
                String command = newStatus + " " + pin + "\n"; // Example: "ON 5" or "OFF 5"
                DashboardPage.serialPort.getOutputStream().write(command.getBytes());
                DashboardPage.serialPort.getOutputStream().flush();
            } else {
                JOptionPane.showMessageDialog(this, "Serial connection not available!");
                return;
            }

            // Update database
            if (newStatus.equals("ON")) {
                String startTime = LocalDateTime.now().format(formatter);
                try (PreparedStatement stmt = connection.prepareStatement(
                        "INSERT INTO devicecontrol (pin, standard_energy, startingontime) VALUES (?, ?, ?)")) {
                    stmt.setInt(1, pin);
                    stmt.setDouble(2, standardEnergy);
                    stmt.setString(3, startTime);
                    stmt.executeUpdate();
                }
            } else {
                String endTime = LocalDateTime.now().format(formatter);
                try (PreparedStatement stmt = connection.prepareStatement(
                        "SELECT id, startingontime, standard_energy FROM devicecontrol WHERE pin = ? ORDER BY id DESC LIMIT 1")) {
                    stmt.setInt(1, pin);
                    ResultSet rs = stmt.executeQuery();
                    if (rs.next()) {
                        int recordId = rs.getInt("id");
                        String startTime = rs.getString("startingontime");
                        double standardEnergyUsed = rs.getDouble("standard_energy");
                        LocalDateTime startDateTime = LocalDateTime.parse(startTime, formatter);
                        LocalDateTime endDateTime = LocalDateTime.parse(endTime, formatter);
                       long duration = Duration.between(startDateTime, endDateTime).toMillis()/366000;

                        double energyConsumption = standardEnergyUsed * duration;

                        try (PreparedStatement updateStmt = connection.prepareStatement(
                                "UPDATE devicecontrol SET endingofftime = ?, duration = ? WHERE id = ?")) {
                            updateStmt.setString(1, endTime);
                            updateStmt.setLong(2, duration);
                            updateStmt.setInt(3, recordId);
                            updateStmt.executeUpdate();
                        }

                        try (PreparedStatement insertTestStmt = connection.prepareStatement(
                                "INSERT INTO test (energy_consumption, time_stamp) VALUES (?, ?)")) {
                            insertTestStmt.setDouble(1, energyConsumption);
                            insertTestStmt.setString(2, endTime);
                            insertTestStmt.executeUpdate();
                        }
                    }
                }
            }

            try (PreparedStatement updateDeviceStmt = connection.prepareStatement(
                    "UPDATE device SET status = ? WHERE pin = ?")) {
                updateDeviceStmt.setString(1, newStatus);
                updateDeviceStmt.setInt(2, pin);
                updateDeviceStmt.executeUpdate();
            }

        } catch (SQLException | IOException ex) {
            JOptionPane.showMessageDialog(this, "Error updating device status.");
            ex.printStackTrace();
        }
    }

































//    private void handleToggleButton(JToggleButton toggleButton, int pin, double standardEnergy) {
//
//        try (Connection connection = DatabaseConfig.getConnection()) {
//            String newStatus = toggleButton.isSelected() ? "ON" : "OFF";
//            toggleButton.setText(newStatus);
//            toggleButton.setBackground(newStatus.equals("ON") ? Color.GREEN : Color.RED);
//
//            if (newStatus.equals("ON")) {
//                String startTime = LocalDateTime.now().format(formatter);
//                try (PreparedStatement stmt = connection.prepareStatement(
//                        "INSERT INTO devicecontrol (pin, standard_energy, startingontime) VALUES (?, ?, ?)")) {
//                    stmt.setInt(1, pin);
//                    stmt.setDouble(2, standardEnergy);
//                    stmt.setString(3, startTime);
//                    stmt.executeUpdate();
//
//                }
//            } else {
//                String endTime = LocalDateTime.now().format(formatter);
//                try (PreparedStatement stmt = connection.prepareStatement(
//                        "SELECT id, startingontime, standard_energy FROM devicecontrol WHERE pin = ? ORDER BY id DESC LIMIT 1")) {
//                    stmt.setInt(1, pin);
//                    ResultSet rs = stmt.executeQuery();
//                    if (rs.next()) {
//                        int recordId = rs.getInt("id");
//                        String startTime = rs.getString("startingontime");
//                        double standardEnergyUsed = rs.getDouble("standard_energy");
//                        LocalDateTime startDateTime = LocalDateTime.parse(startTime, formatter);
//                        LocalDateTime endDateTime = LocalDateTime.parse(endTime, formatter);
//                        long duration = Duration.between(startDateTime, endDateTime).toMillis();
//                        double energyConsumption = standardEnergyUsed * duration;
//
//                        try (PreparedStatement updateStmt = connection.prepareStatement(
//                                "UPDATE devicecontrol SET endingofftime = ?, duration = ? WHERE id = ?")) {
//                            updateStmt.setString(1, endTime);
//                            updateStmt.setLong(2, duration);
//                            updateStmt.setInt(3, recordId);
//                            updateStmt.executeUpdate();
//
//                        }
//
//                        try (PreparedStatement insertTestStmt = connection.prepareStatement(
//                                "INSERT INTO test (energy_consumption, time_stamp) VALUES (?, ?)")) {
//                            insertTestStmt.setDouble(1, energyConsumption);
//                            insertTestStmt.setString(2, endTime);
//                            insertTestStmt.executeUpdate();
//                        }
//                    }
//                }
//            }
//
//            try (PreparedStatement updateDeviceStmt = connection.prepareStatement(
//                    "UPDATE device SET status = ? WHERE pin = ?")) {
//                updateDeviceStmt.setString(1, newStatus);
//                updateDeviceStmt.setInt(2, pin);
//                updateDeviceStmt.executeUpdate();
//            }
//
//        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(this, "Error updating device status.");
//            ex.printStackTrace();
//        }
//    }
}
