import javax.swing.*;
import javax.swing.text.StyledDocument;
import java.awt.*;
import java.sql.*;

public class NotificationPanel extends JFrame {
    private JTextPane notificationArea;
    private StyledDocument doc;

    public NotificationPanel() {
        setTitle("⚡ Smart Home Notifications");
        setSize(450, 350);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Custom styling
        notificationArea = new JTextPane();
        notificationArea.setEditable(false);
        notificationArea.setBackground(new Color(30, 30, 30)); // Dark mode background
        notificationArea.setForeground(Color.WHITE); // Default text color
        notificationArea.setFont(new Font("Arial", Font.PLAIN, 14));
        doc = notificationArea.getStyledDocument();

        JScrollPane scrollPane = new JScrollPane(notificationArea);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        add(scrollPane, BorderLayout.CENTER);

        // Fetch and display notifications
        fetchNotifications();

        setVisible(true);
    }

    private void fetchNotifications() {
        try (Connection conn = DatabaseConfig.getConnection()) {
            String query = "SELECT energy_consumption, time_stamp FROM test ORDER BY time_stamp DESC LIMIT 1";
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                double energyConsumption = rs.getDouble("energy_consumption");
                String timestamp = rs.getString("time_stamp");

                if (energyConsumption > 6000000) {
                    appendText("⚠️ WARNING: High Energy Consumption!\n", Color.RED, 16, true);
                    appendText("Energy Used: " + energyConsumption + " at " + timestamp + "\n\n", Color.ORANGE, 14, false);
                } else {
                    appendText("✅ Latest Energy Usage: " + energyConsumption + " at " + timestamp + "\n\n", Color.GREEN, 14, false);
                }
            } else {
                appendText("❌ No energy data available.\n", Color.GRAY, 14, false);
            }

            // Get the most energy-consuming device
            String deviceQuery = "SELECT devicename, standard_energy FROM device ORDER BY standard_energy DESC LIMIT 1";
            PreparedStatement deviceStmt = conn.prepareStatement(deviceQuery);
            ResultSet deviceRs = deviceStmt.executeQuery();

            if (deviceRs.next()) {
                String deviceName = deviceRs.getString("devicename");
                double energyUsed = deviceRs.getDouble("standard_energy");
                appendText("🔌 Most Energy-Consuming Device: " + deviceName + " (" + energyUsed + " W)\n", Color.CYAN, 14, true);
            }

        } catch (SQLException e) {
            appendText("❌ Error fetching notifications: " + e.getMessage() + "\n", Color.RED, 14, false);
        }
    }

    private void appendText(String text, Color color, int fontSize, boolean bold) {
        try {
            javax.swing.text.Style style = notificationArea.addStyle("Style", null);
            javax.swing.text.StyleConstants.setForeground(style, color);
            javax.swing.text.StyleConstants.setFontSize(style, fontSize);
            if (bold) {
                javax.swing.text.StyleConstants.setBold(style, true);
            }
            doc.insertString(doc.getLength(), text, style);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new NotificationPanel();
    }
}
