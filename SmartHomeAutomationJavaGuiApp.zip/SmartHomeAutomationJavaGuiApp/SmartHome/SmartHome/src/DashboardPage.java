import com.fazecast.jSerialComm.SerialPort;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

public class DashboardPage extends JPanel {
    private JPanel temperaturePanel;
    private JPanel graphPanel;
    private JPanel onlineDevicesPanel;
    public static SerialPort serialPort;
    private JLabel tempLabel;

    public DashboardPage() throws InterruptedException {
        setLayout(new GridLayout(1, 2));

        JPanel leftPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.weightx = 1;
        gbc.fill = GridBagConstraints.BOTH;


        temperaturePanel = new JPanel();
        temperaturePanel.setBorder(BorderFactory.createTitledBorder("Temperature Readings"));
        tempLabel = new JLabel("Loading temperature...", SwingConstants.CENTER);
        temperaturePanel.add(tempLabel);

        gbc.gridy = 0;
        gbc.weighty = 0.25;
        leftPanel.add(temperaturePanel, gbc);


        graphPanel = new JPanel();
        graphPanel.setBorder(BorderFactory.createTitledBorder("Energy Consumption Graph"));
        updateGraph();

        gbc.gridy = 1;
        gbc.weighty = 0.75;
        leftPanel.add(graphPanel, gbc);


        onlineDevicesPanel = new JPanel();
        onlineDevicesPanel.setLayout(new BoxLayout(onlineDevicesPanel, BoxLayout.Y_AXIS));
        onlineDevicesPanel.setBorder(BorderFactory.createTitledBorder("Online Devices"));
        updateOnlineDevices();


        add(leftPanel);
        add(onlineDevicesPanel);

        connectToSerialPort(); // Connect after UI setup
    }

    // creating graph
    private void updateGraph() {
        graphPanel.removeAll();

        XYSeries series = new XYSeries("Energy Consumption");
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/smarthome", "root", "ayalk1995");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT time_stamp, energy_consumption FROM test")) {

            while (rs.next()) {
                double energy = rs.getDouble("energy_consumption");
                series.add(series.getItemCount() + 1, energy);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        XYSeriesCollection dataset = new XYSeriesCollection(series);
        JFreeChart chart = ChartFactory.createXYLineChart(
                "Energy Consumption Over Time",
                "Time", "Consumption (W)",
                dataset, PlotOrientation.VERTICAL,
                true, true, false
        );

        ChartPanel chartPanel = new ChartPanel(chart);
        graphPanel.setLayout(new BorderLayout());
        graphPanel.add(chartPanel, BorderLayout.CENTER);

        graphPanel.revalidate();
        graphPanel.repaint();
    }

    private void connectToSerialPort() throws InterruptedException {
        SerialPort[] ports = SerialPort.getCommPorts();

        if (ports.length == 0) {
            tempLabel.setText("No serial ports found.");
            return;
        }


        String[] portNames = new String[ports.length];
        for (int i = 0; i < ports.length; i++) {
            portNames[i] = ports[i].getSystemPortName();
        }

        String selectedPort = (String) JOptionPane.showInputDialog(
                this,
                "Select the Serial Port:",
                "Serial Port Selection",
                JOptionPane.QUESTION_MESSAGE,
                null,
                portNames,
                portNames[0]
        );

        if (selectedPort == null) {
            tempLabel.setText("No port selected.");
            return;
        }

        for (SerialPort port : ports) {
            if (port.getSystemPortName().equals(selectedPort)) {
                serialPort = port;
                break;
            }
        }

        if (serialPort == null) {
            tempLabel.setText("Invalid port selection.");
            return;
        }

        serialPort.setComPortParameters(38400, 8, 1, 0);
        serialPort.setComPortTimeouts(SerialPort.TIMEOUT_READ_SEMI_BLOCKING, 1000, 0);

        if (serialPort.openPort()) {
            new Thread(this::readTemperatureFromSerial).start();
            Thread.sleep(2000);
        } else {
            tempLabel.setText("Failed to open serial port.");

        }
    }

    private void readTemperatureFromSerial() {
        try (Scanner scanner = new Scanner(serialPort.getInputStream())) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();
                System.out.println("Received from Arduino: " + line); // Debugging output

                if (line.startsWith("TEMP:")) { // Ensure it's a temperature reading
                    String tempString = line.substring(5).trim(); // Extract numeric value

                    try {
                        double temperature = Double.parseDouble(tempString);
                        SwingUtilities.invokeLater(() ->
                                tempLabel.setText("Current Temperature: " + temperature + "°C")
                        );
                    } catch (NumberFormatException e) {
                        System.err.println("Invalid temperature data: " + tempString);
                    }
                } else {
                    System.err.println("Unexpected data format: " + line);
                }
            }
        } catch (Exception e) {
            SwingUtilities.invokeLater(() -> tempLabel.setText("Error reading from serial port."));
            e.printStackTrace();
        }
    }



    private void updateOnlineDevices() {
        onlineDevicesPanel.removeAll();

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/smarthome", "root", "ayalk1995");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT devicename FROM device WHERE status = 'ON'")) {

            ArrayList<String> onlineDevices = new ArrayList<>();
            while (rs.next()) {
                onlineDevices.add(rs.getString("devicename"));
            }

            SwingUtilities.invokeLater(() -> {
                onlineDevicesPanel.removeAll();

                if (onlineDevices.isEmpty()) {
                    onlineDevicesPanel.add(new JLabel("No devices online."));
                } else {
                    for (String device : onlineDevices) {
                        onlineDevicesPanel.add(new JLabel("🟢 " + device));
                    }
                }

                onlineDevicesPanel.revalidate();
                onlineDevicesPanel.repaint();
            });

        } catch (SQLException e) {
            SwingUtilities.invokeLater(() -> {
                onlineDevicesPanel.removeAll();
                onlineDevicesPanel.add(new JLabel("Error fetching devices."));
                onlineDevicesPanel.revalidate();
                onlineDevicesPanel.repaint();
            });
            e.printStackTrace();
        }
    }
}
