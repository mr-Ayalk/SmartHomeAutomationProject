//import com.fazecast.jSerialComm.SerialPort;

import com.fazecast.jSerialComm.SerialPort;

import java.io.IOException;
import java.util.Scanner;

public class SerialConnection {
    private SerialPort serialPort;

    // Connect to the first available port
    public boolean connectToAvailablePort() {
        SerialPort[] ports = SerialPort.getCommPorts();

        if (ports.length == 0) {
            System.err.println("No available serial ports found.");
            return false;
        }

        System.out.println("Available ports:");
        for (int i = 0; i < ports.length; i++) {
            System.out.println((i + 1) + ". " + ports[i].getSystemPortName());
        }

        Scanner scanner = new Scanner(System.in);
        System.out.print("Select the port to connect (1-" + ports.length + "): ");
        int choice = scanner.nextInt();

        if (choice < 1 || choice > ports.length) {
            System.err.println("Invalid selection.");
            return false;
        }

        serialPort = ports[choice - 1];
        serialPort.setComPortParameters(9600, 8, 1, 0);
        serialPort.setComPortTimeouts(SerialPort.TIMEOUT_WRITE_BLOCKING, 1000, 1000);

        if (serialPort.openPort()) {
            System.out.println("Connected to " + serialPort.getSystemPortName());
            return true;
        } else {
            System.err.println("Failed to open the port: " + serialPort.getSystemPortName());
            return false;
        }
    }

    // Send data to the connected port
    public void sendData(byte pin, byte state) {
        try {
            if (serialPort != null && serialPort.isOpen()) {
                serialPort.getOutputStream().write(new byte[]{pin, state});
                serialPort.getOutputStream().flush();
            }
        } catch (IOException e) {
            System.err.println("Error sending data: " + e.getMessage());
        }
    }

    // Close the port
    public void close() {
        if (serialPort != null) {
            serialPort.closePort();
            System.out.println("Port closed.");
        }
    }
}
