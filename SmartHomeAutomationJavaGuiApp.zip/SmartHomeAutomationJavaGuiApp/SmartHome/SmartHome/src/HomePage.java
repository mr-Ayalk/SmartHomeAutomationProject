import javax.swing.*;
import java.awt.*;

public class HomePage extends JFrame {
    private String username;
    private CardLayout cardLayout;
    private JPanel contentPanel;

    public HomePage(String username) throws InterruptedException {
        this.username = username;

        setTitle("Smart Home System - Home Page");
        setSize(800, 600);
        setMinimumSize(new Dimension(800, 600));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());


        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);


        contentPanel.add(new DashboardPage(), "Dashboard");
        contentPanel.add(new DeviceControlPage(), "DeviceControl");
        contentPanel.add(new SchedulePage(), "Schedule");
        contentPanel.add(new AddDevicePage(), "AddDevice");
        contentPanel.add(new BillReportPage(), "BillReport");


        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

        JButton dashboardBtn = new JButton("Dashboard");
        JButton deviceControlBtn = new JButton("Device Control");
        JButton scheduleBtn = new JButton("Schedule");
        JButton addDeviceBtn = new JButton("Add Device");
        JButton billReportBtn = new JButton("Bill Report");  // New Bill Report Button


        dashboardBtn.addActionListener(e -> cardLayout.show(contentPanel, "Dashboard"));
        deviceControlBtn.addActionListener(e -> cardLayout.show(contentPanel, "DeviceControl"));
        scheduleBtn.addActionListener(e -> cardLayout.show(contentPanel, "Schedule"));
        addDeviceBtn.addActionListener(e -> cardLayout.show(contentPanel, "AddDevice"));
        billReportBtn.addActionListener(e -> cardLayout.show(contentPanel, "BillReport"));  // Show Bill Report Page


        topPanel.add(dashboardBtn);
        topPanel.add(deviceControlBtn);
        topPanel.add(scheduleBtn);
        topPanel.add(addDeviceBtn);
        topPanel.add(billReportBtn);


        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));

        JButton notificationBtn = new JButton("\uD83D\uDD14");
        notificationBtn.setToolTipText("Notifications");
        notificationBtn.addActionListener(e -> new NotificationPanel());


        JButton userIconBtn = new JButton("\uD83D\uDC64");
        userIconBtn.setToolTipText("User Options");

        JPopupMenu userMenu = new JPopupMenu();
        JMenuItem achievements = new JMenuItem("Achievements");
        JMenuItem inviteFriends = new JMenuItem("Invite Friends");
        JMenuItem aboutUs = new JMenuItem("About Us");
        JMenuItem logout = new JMenuItem("Log Out");


        logout.addActionListener(e -> {
            dispose();
            LoginPage.main(null);
        });


        userMenu.add(achievements);
        userMenu.add(inviteFriends);
        userMenu.add(aboutUs);
        userMenu.add(logout);


        userIconBtn.addActionListener(e -> userMenu.show(userIconBtn, 0, userIconBtn.getHeight()));


        rightPanel.add(notificationBtn);
        rightPanel.add(userIconBtn);

        JPanel topContainer = new JPanel(new BorderLayout());
        topContainer.add(topPanel, BorderLayout.WEST);
        topContainer.add(rightPanel, BorderLayout.EAST);


        add(topContainer, BorderLayout.NORTH);
        add(contentPanel, BorderLayout.CENTER);

        setVisible(true);
    }

}
