import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class BillReportPage extends JPanel {
    private static final double STANDARD_PRICE = 70.0;
    private JTable billTable;
    private JLabel totalBillLabel;
    private DefaultTableModel tableModel;

    public BillReportPage() {
        setLayout(new BorderLayout());
        setBackground(new Color(240, 248, 255)); // Light Blue Background

        // Title Label Styling
        JLabel titleLabel = new JLabel("Bill Report", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 22));
        titleLabel.setOpaque(true);
        titleLabel.setBackground(new Color(30, 144, 255)); // Dodger Blue
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBorder(new LineBorder(Color.BLUE, 2));
        titleLabel.setPreferredSize(new Dimension(100, 50));

        // Table Setup
        String[] columnNames = {"Device Name", "Energy (W)", "Times Switched", "Total Duration (sec)", "Bill Amount ($)"};
        tableModel = new DefaultTableModel(columnNames, 0);
        billTable = new JTable(tableModel);
        billTable.setFillsViewportHeight(true);
        billTable.setFont(new Font("Arial", Font.PLAIN, 14));
        billTable.setRowHeight(25);
        billTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        billTable.getTableHeader().setBackground(new Color(65, 105, 225)); // Royal Blue
        billTable.getTableHeader().setForeground(Color.WHITE);

        // Apply alternating row colors
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                c.setBackground(row % 2 == 0 ? Color.WHITE : new Color(230, 240, 255)); // Alternate Row Colors
                return c;
            }
        };

        for (int i = 0; i < billTable.getColumnCount(); i++) {
            billTable.getColumnModel().getColumn(i).setCellRenderer(renderer);
        }

        // Total Bill Label
        totalBillLabel = new JLabel("Total Bill: 0.00", SwingConstants.CENTER);
        totalBillLabel.setFont(new Font("Arial", Font.BOLD, 16));
        totalBillLabel.setForeground(Color.RED);
        totalBillLabel.setOpaque(true);
        totalBillLabel.setBackground(Color.WHITE);
        totalBillLabel.setBorder(new LineBorder(Color.RED, 2));
        totalBillLabel.setPreferredSize(new Dimension(100, 40));

        // Adding Components
        add(titleLabel, BorderLayout.NORTH);
        add(new JScrollPane(billTable), BorderLayout.CENTER);
        add(totalBillLabel, BorderLayout.SOUTH);

        // Load Data Initially
        generateBillReport();

        // Start Auto-Refresh Every 5 Seconds
        Timer timer = new Timer(5000, e -> generateBillReport());
        timer.start();
    }

    private void generateBillReport() {
        double totalBill = 0;

        // Clear previous data
        tableModel.setRowCount(0);

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/smarthome", "root", "ayalk1995")) {
            String query = "SELECT d.devicename, d.standard_energy, COUNT(dc.id) AS switch_count, " +
                    "SUM(dc.duration) AS total_duration " +
                    "FROM device d " +
                    "JOIN devicecontrol dc ON d.pin = dc.pin " +
                    "GROUP BY d.devicename, d.standard_energy";

            try (PreparedStatement pstmt = conn.prepareStatement(query);
                 ResultSet rs = pstmt.executeQuery()) {

                while (rs.next()) {
                    String devicename = rs.getString("devicename");
                    double standardEnergy = rs.getDouble("standard_energy");
                    int switchCount = rs.getInt("switch_count");
                    int totalDuration = rs.getInt("total_duration");

                    double billAmount = (STANDARD_PRICE * standardEnergy * switchCount * (totalDuration / 60.0)) / 1000000;
                    totalBill += billAmount;

                    tableModel.addRow(new Object[]{devicename, standardEnergy, switchCount, totalDuration, String.format("$%.2f", billAmount)});
                }

                totalBillLabel.setText(String.format("Total Bill: $%.2f", totalBill));
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error fetching bill report: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
