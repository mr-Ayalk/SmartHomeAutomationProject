import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SchedulePage extends JPanel {
    private JTable scheduleTable;
    private DefaultTableModel tableModel;
    private JButton scheduleButton, cancelScheduleButton;

    public SchedulePage() {
        setLayout(new BorderLayout());
        setBackground(new Color(230, 240, 255)); // Light pastel blue background

        // Title Label Styling
        JLabel titleLabel = new JLabel("Schedule Management", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 22));
        titleLabel.setOpaque(true);
        titleLabel.setBackground(new Color(30, 144, 255)); // Dodger Blue
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBorder(new LineBorder(Color.BLUE, 2));
        titleLabel.setPreferredSize(new Dimension(100, 50));

        // Table model with columns
        String[] columns = {"Device Name", "Start Time", "End Time"};
        tableModel = new DefaultTableModel(columns, 0);
        scheduleTable = new JTable(tableModel);
        scheduleTable.setFont(new Font("Arial", Font.PLAIN, 14));
        scheduleTable.setRowHeight(25);

        // Table Header Styling
        scheduleTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 14));
        scheduleTable.getTableHeader().setBackground(new Color(0, 102, 204)); // Dark Blue
        scheduleTable.getTableHeader().setForeground(Color.WHITE);

        // Apply alternating row colors
        DefaultTableCellRenderer renderer = new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                c.setBackground(row % 2 == 0 ? Color.WHITE : new Color(230, 230, 230)); // Alternate colors
                return c;
            }
        };
        for (int i = 0; i < scheduleTable.getColumnCount(); i++) {
            scheduleTable.getColumnModel().getColumn(i).setCellRenderer(renderer);
        }

        JScrollPane scrollPane = new JScrollPane(scheduleTable);

        // Buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(230, 240, 255));

        scheduleButton = createStyledButton("Schedule", new Color(50, 205, 50)); // Green
        cancelScheduleButton = createStyledButton("Cancel Schedule", new Color(255, 69, 0)); // Red

        buttonPanel.add(scheduleButton);
        buttonPanel.add(cancelScheduleButton);

        // Fetch devices from database
        loadDevices();

        // Schedule button action
        scheduleButton.addActionListener(e -> scheduleDevice());

        // Cancel schedule button action
        cancelScheduleButton.addActionListener(e -> cancelSchedule());

        // Add components to panel
        add(titleLabel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    // Load devices from database
    private void loadDevices() {
        try (Connection connection = DatabaseConfig.getConnection()) {
            String query = "SELECT devicename FROM device";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String deviceName = resultSet.getString("devicename");
                tableModel.addRow(new Object[]{deviceName, "", ""});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading devices from database.", "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    // Schedule a device
    private void scheduleDevice() {
        int selectedRow = scheduleTable.getSelectedRow();
        if (selectedRow != -1) {
            String startTime = JOptionPane.showInputDialog(this, "Enter Start Time (HH:MM):");
            String endTime = JOptionPane.showInputDialog(this, "Enter End Time (HH:MM):");

            if (startTime != null && endTime != null && !startTime.isEmpty() && !endTime.isEmpty()) {
                tableModel.setValueAt(startTime, selectedRow, 1);
                tableModel.setValueAt(endTime, selectedRow, 2);
                JOptionPane.showMessageDialog(this, "Device scheduled successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Start Time and End Time cannot be empty.", "Input Error", JOptionPane.WARNING_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a device to schedule.", "Selection Error", JOptionPane.WARNING_MESSAGE);
        }
    }

    // Cancel a schedule
    private void cancelSchedule() {
        int selectedRow = scheduleTable.getSelectedRow();
        if (selectedRow != -1) {
            tableModel.setValueAt("", selectedRow, 1);
            tableModel.setValueAt("", selectedRow, 2);
            JOptionPane.showMessageDialog(this, "Schedule canceled!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Please select a scheduled device to cancel.", "Selection Error", JOptionPane.WARNING_MESSAGE);
        }
    }

    // Method to create styled buttons
    private JButton createStyledButton(String text, Color backgroundColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setForeground(Color.WHITE);
        button.setBackground(backgroundColor);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }
}
