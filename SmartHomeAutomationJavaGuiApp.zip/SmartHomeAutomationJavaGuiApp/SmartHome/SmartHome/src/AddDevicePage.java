import javax.swing.*;
        import javax.swing.table.DefaultTableModel;
import java.awt.*;
        import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AddDevicePage extends JPanel {
    private JTable deviceTable;
    private DefaultTableModel tableModel;
    private JButton addDeviceButton, removeDeviceButton, saveButton;
    private JPanel tablePanel, deviceListPanel;
    private boolean isSaved = false;



    public AddDevicePage() {
        setLayout(new BorderLayout());

        // Welcome message and proverb
        JPanel welcomePanel = new JPanel();
        JLabel welcomeLabel = new JLabel("<html><h2>Welcome to Device Control Page</h2><p>Make your life easier by controlling your devices from anywhere!</p></html>", SwingConstants.CENTER);
        welcomePanel.add(welcomeLabel);

        // Buttons panel
        JPanel buttonPanel = new JPanel();
        addDeviceButton = new JButton("Add Device");
        removeDeviceButton = new JButton("Remove Device");
        saveButton = new JButton("Save");

        buttonPanel.add(addDeviceButton);
        buttonPanel.add(removeDeviceButton);
        buttonPanel.add(saveButton);

        // Table panel (Initially hidden, without ID column)
        tablePanel = new JPanel(new BorderLayout());
        String[] columns = {"Device Name", "Pin", "Standard Energy"};
        tableModel = new DefaultTableModel(columns, 0);
        deviceTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(deviceTable);
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        tablePanel.setVisible(false);

        // Device list panel (For displaying saved devices with toggle buttons)
        deviceListPanel = new JPanel();
        deviceListPanel.setLayout(new BoxLayout(deviceListPanel, BoxLayout.Y_AXIS));
        deviceListPanel.setVisible(false);

        // Button actions
        addDeviceButton.addActionListener(e -> addDeviceRow());
        removeDeviceButton.addActionListener(e -> removeSelectedDevice());
        saveButton.addActionListener(e -> saveDevices());

        // Add components to main layout
        add(welcomePanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.SOUTH);
        add(tablePanel, BorderLayout.CENTER);
        add(deviceListPanel, BorderLayout.EAST);
    }

    // Add a new row to the table
    private void addDeviceRow() {
        tablePanel.setVisible(true);
        deviceListPanel.setVisible(false);
        tableModel.addRow(new Object[]{"", "", ""});
    }

    // Remove selected device from table
    private void removeSelectedDevice() {
        int selectedRow = deviceTable.getSelectedRow();
        if (selectedRow != -1) {
            tableModel.removeRow(selectedRow);
        } else {
            JOptionPane.showMessageDialog(this, "Please select a device to remove.");
        }
    }

    // Save devices and store them in the database
    private void saveDevices() {
        if (tableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No devices to save!");
            return;
        }

        // Insert devices into the database
        try (Connection connection = DatabaseConfig.getConnection()) {
            String insertQuery = "INSERT INTO device (devicename, pin, standard_energy) VALUES (?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(insertQuery);

            // Loop through the table rows and insert into database
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                String deviceName = (String) tableModel.getValueAt(i, 0);  // Device Name column
                String pin = (String) tableModel.getValueAt(i, 1);         // Pin column
                String standardEnergy = (String) tableModel.getValueAt(i, 2); // Standard Energy column

                if (deviceName.isEmpty() || pin.isEmpty() || standardEnergy.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Please fill in all fields.");
                    return;
                }

                preparedStatement.setString(1, deviceName);
                preparedStatement.setString(2, pin);
                preparedStatement.setString(3, standardEnergy);
                preparedStatement.executeUpdate();
            }

            // Show success message and devices list
            deviceListPanel.setVisible(true);
            JOptionPane.showMessageDialog(this, "Devices saved successfully!");

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error saving devices to the database.");
            e.printStackTrace();
        }
    }
}
