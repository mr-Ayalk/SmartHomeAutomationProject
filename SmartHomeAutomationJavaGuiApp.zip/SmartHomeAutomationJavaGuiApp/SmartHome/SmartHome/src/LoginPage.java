import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginPage  {
    public static void main(String[] args) {

        JFrame frame = new JFrame("\"ከዘመኑ ጋር ይዘምኑ።\"");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        frame.setMinimumSize(new Dimension(800, 600));
        frame.setLocation(150,100);
        frame.setLayout(new CardLayout());

        JPanel loginPanel = createLoginPanel(frame);
        JPanel registrationPanel = createRegistrationPanel(frame);

        frame.add(loginPanel, "Login");
        frame.add(registrationPanel, "Register");

        CardLayout cl = (CardLayout) frame.getContentPane().getLayout();
        cl.show(frame.getContentPane(), "Login");

        frame.setVisible(true);
    }

    private static JPanel createLoginPanel(JFrame frame) {
        JPanel loginPanel = new JPanel();
        loginPanel.setBackground(new Color(134, 133, 239, 255));
        loginPanel.setLayout(null);

        JLabel titleLabel = new JLabel("Login to your account");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setBounds(100, 20, 200, 30);
        loginPanel.add(titleLabel);

        JLabel usernameLabel = new JLabel("Username");
        usernameLabel.setBounds(50, 80, 100, 25);
        loginPanel.add(usernameLabel);

        JTextField usernameField = new JTextField();
        usernameField.setBounds(50, 110, 300, 30);
        loginPanel.add(usernameField);

        JLabel roleLabel = new JLabel("Role");
        roleLabel.setBounds(50, 150, 100, 25);
        loginPanel.add(roleLabel);

        JComboBox<String> roleComboBox = new JComboBox<>(new String[]{
                "Owner", "Guest"
        });
        roleComboBox.setBounds(50, 180, 300, 30);
        loginPanel.add(roleComboBox);

        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setBounds(50, 220, 100, 25);
        loginPanel.add(passwordLabel);

        JPasswordField passwordField = new JPasswordField();
        passwordField.setBounds(50, 250, 300, 30);
        loginPanel.add(passwordField);

        JButton loginButton = new JButton("Login");
        loginButton.setBackground(new Color(167, 170, 189));
        loginButton.setForeground(Color.WHITE);
        loginButton.setBounds(50, 300, 300, 40);
        loginPanel.add(loginButton);

        loginButton.addActionListener(e -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            String role = (String) roleComboBox.getSelectedItem();

            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please fill in all fields", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                try (Connection connection = DatabaseConfig.getConnection()) {
                    String query = "SELECT * FROM userinfo WHERE username = ? AND password = ? AND role = ?";

                    PreparedStatement preparedStatement = connection.prepareStatement(query);
                    preparedStatement.setString(1, username);
                    preparedStatement.setString(2, password);
                    preparedStatement.setString(3, role);

                    ResultSet resultSet = preparedStatement.executeQuery();

                    if (resultSet.next()) {
                        JOptionPane.showMessageDialog(frame, "Login successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                        frame.dispose();
                        HomePage homePage = new HomePage(username);
                        homePage.setVisible(true);
                    } else {
                        JOptionPane.showMessageDialog(frame, "Invalid credentials", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(frame, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                } catch (InterruptedException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });



        JLabel createAccountLabel = new JLabel("Don’t have an account? Create a new account");
        createAccountLabel.setForeground(new Color(255, 0, 0));
        createAccountLabel.setBounds(50, 350, 300, 25);
        loginPanel.add(createAccountLabel);

        createAccountLabel.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        createAccountLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CardLayout cl = (CardLayout) frame.getContentPane().getLayout();
                cl.show(frame.getContentPane(), "Register");
            }
        });

        JLabel rightTitleLabel = new JLabel("About Our Smart Home and Energy System");
        rightTitleLabel.setFont(new Font("Arial", Font.BOLD, 16));
        rightTitleLabel.setBounds(400, 50, 350, 30);
        loginPanel.add(rightTitleLabel);

        JLabel descriptionLabel = new JLabel("\"Smart Home and Automation System.\"");
        descriptionLabel.setBounds(400, 90, 350, 25);
        loginPanel.add(descriptionLabel);

        JButton createAccountButton = new JButton("Create a New Account");
        createAccountButton.setBounds(400, 130, 300, 40);
        createAccountButton.setBackground(new Color(167, 170, 189));
        createAccountButton.setForeground(Color.WHITE);
        loginPanel.add(createAccountButton);


        createAccountButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CardLayout cl = (CardLayout) frame.getContentPane().getLayout();
                cl.show(frame.getContentPane(), "Register");
            }
        });

        return loginPanel;
    }

    private static JPanel createRegistrationPanel(JFrame frame) {
        JPanel registrationPanel = new JPanel();
        registrationPanel.setBackground(new Color(134, 133, 239));
        registrationPanel.setLayout(null);

        JLabel registrationTitle = new JLabel("Welcome to our Smart Home and Automation System");
        registrationTitle.setFont(new Font("Arial", Font.BOLD, 18));
        registrationTitle.setBounds(100, 20, 500, 30);
        registrationPanel.add(registrationTitle);

        JLabel usernameLabel = new JLabel("Username");
        usernameLabel.setBounds(50, 80, 100, 25);
        registrationPanel.add(usernameLabel);

        JTextField usernameField = new JTextField();
        usernameField.setBounds(50, 110, 300, 30);
        registrationPanel.add(usernameField);


        JLabel housenumberLabel = new JLabel("House Number");
        housenumberLabel.setBounds(50, 150, 100, 25);
        registrationPanel.add(housenumberLabel);

        JTextField housenumberField = new JTextField();
        housenumberField.setBounds(50, 180, 300, 30);
        registrationPanel.add(housenumberField);


        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setBounds(50, 220, 100, 25);
        registrationPanel.add(passwordLabel);

        JPasswordField passwordField = new JPasswordField();
        passwordField.setBounds(50, 250, 300, 30);
        registrationPanel.add(passwordField);

        JCheckBox ownerCheckBox = new JCheckBox("I am a Owner");
        ownerCheckBox.setBounds(50, 290, 300, 25);
        registrationPanel.add(ownerCheckBox);

        JCheckBox termsCheckBox = new JCheckBox("I agree to the privacy policy and terms of service.");
        termsCheckBox.setBounds(50, 310, 300, 25);
        registrationPanel.add(termsCheckBox);

        JButton agreeAndJoinButton = new JButton("Agree and Join");
        agreeAndJoinButton.setBackground(new Color(225, 0, 0));
        agreeAndJoinButton.setForeground(Color.WHITE);
        agreeAndJoinButton.setBounds(50, 340, 300, 40);
        registrationPanel.add(agreeAndJoinButton);

        agreeAndJoinButton.addActionListener(e -> {
            String username = usernameField.getText();
            String houseNumber = housenumberField.getText();
            String password = new String(passwordField.getPassword());

            if (username.isEmpty() || houseNumber.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please fill in all fields", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                try (Connection connection = DatabaseConfig.getConnection()) {
                    String query = "INSERT INTO userinfo (username, house_number, password) VALUES (?, ?, ?)";
                    PreparedStatement preparedStatement = connection.prepareStatement(query);
                    preparedStatement.setString(1, username);
                    preparedStatement.setString(2, houseNumber);
                    preparedStatement.setString(3, password);
                    int rowsAffected = preparedStatement.executeUpdate();

                    if (rowsAffected > 0) {
                        JOptionPane.showMessageDialog(frame, "Registration successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                        CardLayout cl = (CardLayout) frame.getContentPane().getLayout();
                        cl.show(frame.getContentPane(), "Login");
                    } else {
                        JOptionPane.showMessageDialog(frame, "Registration failed", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(frame, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        JButton backButton = new JButton("Back");
        backButton.setBounds(50, 390, 300, 40);
        backButton.setBackground(new Color(167, 170, 189));
        backButton.setForeground(Color.WHITE);
        registrationPanel.add(backButton);

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CardLayout cl = (CardLayout) frame.getContentPane().getLayout();
                cl.show(frame.getContentPane(), "Login");
            }
        });

        return registrationPanel;
    }
}
